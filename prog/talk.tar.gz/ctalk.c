//ctalk.c
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <signal.h>
#define Port 5656
#define MAX 50
#define serverIP "192.168.1.23"
int main(void){
	int socket_fd,connect_fd,ret;
	int fd,num=0,i=0,j=0;
	char buf[MAX];
	size_t size;
	struct sockaddr_in sin;
	if((socket_fd=socket(AF_INET,SOCK_STREAM,0)) < 0){
		printf("creat socket error\n");
		exit (1);
	}
	bzero(&sin,sizeof(sin));
	sin.sin_family=AF_INET;
	sin.sin_addr.s_addr=inet_addr(serverIP);
	sin.sin_port=htons(Port);

	if((connect(socket_fd,(struct sockaddr *)&sin,sizeof(sin))) < 0 ) {
		printf("connect error\n");
		exit (1);
	}

	printf("\033[2J\033[0;0fConnected success!\n");
	fflush(stdout);
	if(fork()==0){
		while(fgets(buf, sizeof(buf), stdin)){
			buf[MAX-1]='\0';
			num=strlen(buf)+1;
			send(socket_fd,buf,num,0); 
			//printf("I Say: %s",buf);
		}
	}
	else
		while(num=recv(socket_fd,buf,sizeof(buf),0)){
			printf("Server Say: ");
			fputs(buf,stdout);
		}
	close(socket_fd);
	return 0;
}
