//stalk.c
#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <string.h>
#include <stdlib.h>
#define Port 5656
#define MAX 50
#define serverIP "192.168.1.23" 
int main(){
	int socket_fd,connect_fd;
	char buf[MAX];
	int num;

	socklen_t len = sizeof (struct sockaddr_in);
	struct sockaddr_in server_addr;

	if ((socket_fd=socket(AF_INET,SOCK_STREAM,0)) < 0)
		printf("creat socket error\n");
	bzero(&server_addr, sizeof(server_addr));  

	server_addr.sin_family = AF_INET;                 
	server_addr.sin_port = htons(Port);            
	server_addr.sin_addr.s_addr = inet_addr(serverIP);

	if ((bind(socket_fd,(struct sockaddr *) &server_addr,sizeof(server_addr))) < 0){
		printf("bind error\n");	
		exit (1);
	}
	printf("Lestining......\n");
	if ((listen(socket_fd,3)) <0){
		printf("listen error\n");
		exit (1);
	}
	if((connect_fd = accept(socket_fd, (struct sockaddr *) &server_addr,&len)) < 0){
		printf("accept error\n");
		exit (1);
	}
	bzero (buf, sizeof (buf));
	printf("\033[2J\033[0;0fConnected success!\n");
        fflush(stdout);
	
	if(fork()==0)
		while(num=recv(connect_fd,buf,sizeof(buf),0)){
			printf("Client Say: ");
			fputs(buf,stdout);
	}
	else
		while(fgets(buf, sizeof(buf), stdin)){
			buf[MAX-1]='\0';
			num=strlen(buf)+1;
			send(connect_fd,buf,num,0);
		//	printf("I Say: %s",buf);
		}	
	close(connect_fd);
	close(socket_fd);
	return 0;
}
