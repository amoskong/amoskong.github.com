#!/bin/bash

cp arp.sh /usr/bin/
echo arp.sh >>  /etc/rc.local
exit 0
