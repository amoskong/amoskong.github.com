#coding: utf-8

f=open('arp.sh','r')
f2=open('mac2.txt','w')
for item in f.readlines():
    if item.split(' ')[0]=='arp':
	mac=item.split(' ')[-2:]
	#mac=mac.split('\n')[0]
	f2.write('%s %s' %(mac[0],mac[1]))
f.close()
f2.close()

