#coding: utf-8
IP_NET='192.168.200'
IP_DNS='202.117.128.2'
def creat():
    f=open('mac.txt','r')

    f2=open('arp.sh','w')
    str1='#!/bin/bash\n\nifup eth1\necho "1" >/proc/sys/net/ipv4/ip_forward\n\niptables -t nat -F\niptables -t filter -F\niptables -t mangle -F\n\n'
    str2='#智能DNS\niptables -t nat -I PREROUTING -i eth0 -p udp --dport 53 -j DNAT --to-destination %s:53\niptables -t nat -I PREROUTING -i eth0 -p tcp --dport 53 -j DNAT --to-destination %s:53\n\n' %(IP_DNS,IP_DNS)
    str3='iptables -t nat -A POSTROUTING -o eth1 -s %s.0/24 -j MASQUERADE\n\n' %IP_NET

    f2.write(str1+str2+str3)
    f2.close()
    f2=open('arp.sh','a')
    i=1
    for item in f.readlines():
	if i>255:
	    break
        item=item.split('\n')[0]
        if item=='':
            continue
        str='arp -s %s.%d %s\n' %(IP_NET,i,item)

        f2.write(str)
        i+=1

    f.close()
    f2.close()
